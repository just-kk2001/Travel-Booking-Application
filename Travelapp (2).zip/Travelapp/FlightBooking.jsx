import React from 'react';
import { useParams } from 'react-router-dom';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import './FlightBooking.css';

const FlightBooking = () => {
  const { destinationName } = useParams();  
  const [departureDate, setDepartureDate] = React.useState(null);
  const [returnDate, setReturnDate] = React.useState(null);

  const handleSearch = () => {
    
    console.log('Searching flights for:', destinationName, 'from:', departureDate, 'to:', returnDate);
  };

  return (
    <div className="flight-booking">
      <h1>Book a Flight to {destinationName}</h1>
      <div className="date-picker-container">
        <div className="date-picker">
          <label>Departure Date:</label>
          <DatePicker
            selected={departureDate}
            onChange={(date) => setDepartureDate(date)}
            dateFormat="dd/MM/yyyy"
            placeholderText="Select a departure date"
          />
        </div>
        <div className="date-picker">
          <label>Return Date:</label>
          <DatePicker
            selected={returnDate}
            onChange={(date) => setReturnDate(date)}
            dateFormat="dd/MM/yyyy"
            placeholderText="Select a return date"
          />
        </div>
      </div>
      <button onClick={handleSearch}>Search Flights</button>
    </div>
  );
};

export default FlightBooking;
