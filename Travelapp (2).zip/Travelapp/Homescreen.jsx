import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './HomeScreen.css'; 

const destinations = [
  { name: 'Paris', image: 'https://media.istockphoto.com/id/1463510971/photo/paris-france.webp?a=1&b=1&s=612x612&w=0&k=20&c=4F64zAzQM5oSLMr9DrbCyOkLECslFIHXx9t5HDY2xNk=', description: 'The city of lights', region: 'Europe' },
  { name: 'New York', image: 'https://media.gettyimages.com/id/904453184/photo/composite-image-of-mt-fuji-and-tokyo-skyline.jpg?s=612x612&w=0&k=20&c=EAJrI5nVsDuIkiv7o3NY1LsaZHRCcOWUOvk2g9FfFD0=', description: 'The big apple', region: 'North America' },
  { name: 'Tokyo', image: 'https://media.gettyimages.com/id/1459138081/photo/tokyo-sky-tree-tower-in-asakusa-district-tokyo-japan.jpg?s=612x612&w=0&k=20&c=GtqIvoVXY3DgQ4YOxKNisWgQJGZvCQ_6OYFHRccngTQ=', description: 'Explore the land of the rising sun', region: 'Asia' },
  { name: 'Rome', image: 'https://media.istockphoto.com/id/1346359672/photo/rome-italy.jpg?s=612x612&w=0&k=20&c=VX2Blx_hNQaRWNcjMMggMqwaK_YCXJ109Rk0IlE5nPA=', description: 'The eternal city', region: 'Europe' },
  { name: 'Bali', image: 'https://media.gettyimages.com/id/113824076/photo/floating-temple-bali.jpg?s=612x612&w=0&k=20&c=I36xFLAzGUuUMybmM9RUstLPa1bPTJXELXurIAQ91zU=', description: 'A tropical paradise', region: 'Asia' },
  { name: 'Sydney', image: 'https://media.gettyimages.com/id/468994239/photo/sydney.jpg?s=612x612&w=0&k=20&c=16AnH70SaaHh02GzTSrItExrDNXm3ZU1XnrzL8Ro6PU=', description: 'Famous for the Opera House', region: 'Australia' },
  { name: 'Dubai', image: 'https://media.istockphoto.com/id/1572334424/photo/dubai.jpg?s=612x612&w=0&k=20&c=pfiT0UlQD8fyF4zowN4uCToAcnCs8V11Ke-HSte_ooc=', description: 'A city of innovation', region: 'Middle East' },
  { name: 'Cairo', image: 'https://media.istockphoto.com/id/177039612/photo/tutankhamuns-funerary-mask.jpg?s=612x612&w=0&k=20&c=T_s3dFgH16fGVb_uP5pqDo7SWL1Qf4U2IeN3jPWEM4c=', description: 'Home to the pyramids', region: 'Africa' },
  { name: 'Victoria Falls', image: 'https://t3.ftcdn.net/jpg/07/37/75/20/360_F_737752046_EQQifjCVIv0b61vaPxBveg0zdVZTGZpv.jpg', description: 'Most spectacular waterfalls.', region: 'Africa' },
  { name: 'Pyramids of Giza', image: 'https://cdn-imgix.headout.com/mircobrands-content/image/71e15c4888f28f40a0a4e05bc5cde87b-osama-elsayed-vqRMXgVtGXM-unsplash.jpg?auto=format&w=1051.2&h=540&q=90&fit=fit', description: 'Ancient wonders and iconic structures', region: 'Africa' },
  { name: 'Agra', image: 'https://t4.ftcdn.net/jpg/05/22/08/63/360_F_522086374_baK6AUM90Eg5It4iGa4EBXO7QomOgxeu.jpg', description: 'Taj Mahal INDIA', region: 'Asia' },
  { name: 'Mount Fuji', image: 'https://media.gettyimages.com/id/1163659775/photo/mount-fuji-japan.jpg?s=612x612&w=0&k=20&c=bqUEYZIlWCPZpY9EqvjLn-g3jHQHxPFHHGGz9xSREBs=', description: 'A beautiful, iconic volcano.', region: 'Asia' },
  { name: 'Eiffel Tower', image: 'https://i0.wp.com/www.theparisphotographer.com/wp-content/uploads/2021/07/Cute-photos-with-the-Eiffel-Tower.jpg?resize=668,1000&quality=100&ssl=1', description: 'A world-famous landmark in Paris.', region: 'Europe' },
  { name: 'Santorini', image: 'https://media.gettyimages.com/id/504544111/photo/santorini-greece.jpg?s=612x612&w=0&k=20&c=MwBH3AJWwaxnXJ3prY7oDjhV2BPWJPd3OEDhvwQQAvU=', description: 'Whitewashed buildings and stunning sunsets.', region: 'Europe' },
  { name: 'Swiss Alps', image: 'https://media.gettyimages.com/id/AB13082/photo/switzerland-swiss-alps-mountains-reflected-in-lake-water.jpg?s=612x612&w=0&k=20&c=8s_HgpsazV5FBnwdpfgh4gWB-006scZ7Is4ZGdejImI=', description: 'Majestic mountains for skiing and hiking.', region: 'Europe' },
  { name: 'Uluru', image: 'https://media.istockphoto.com/id/697901510/photo/uluru-at-sunset.jpg?s=612x612&w=0&k=20&c=QLo0oo2_vnKHjb2_tasm331UScJmSfC80AYufD0haFo=', description: 'A massive sandstone monolith in the Northern Territory', region: 'Australia' },
  { name: 'Great Wall of China (China)', image: 'https://media.istockphoto.com/id/500798097/photo/china-view-of-great-wall.jpg?s=612x612&w=0&k=20&c=bFk_2RzX47-_JqUXembpqJVzFujWSWmu8_kswDGdFK4=', description: 'One of the worlds greatest wonders', region: 'Asia' },
  { name: 'Angkor Wat (Cambodia)', image: 'https://i.natgeofe.com/n/ecc4af4e-7bd2-40cc-a854-62ca89d7f96b/93405.jpg', description: 'A stunning temple complex.', region: 'Asia' },
  { name: 'SColosseum (Italy) ', image: 'https://images.nationalgeographic.org/image/upload/t_edhub_resource_key_image/v1652340658/EducationHub/photos/colosseum.jpg', description: ' An ancient Roman amphitheater in Rome', region: 'Europe' },
  { name: 'Sagrada Familia (Spain) ', image: 'https://www.thevintagenews.com/wp-content/uploads/sites/65/2019/06/sagrada-familia-cathedral-in-barcelona-picture-id481444484.jpg', description: ' A unique basilica in Barcelona, designed by Gaudí.', region: 'Europe' },
  { name: 'Grand Canyon (USA)', image: 'https://t3.ftcdn.net/jpg/03/41/96/18/360_F_341961895_qTWc1ePPmvEAYHm5sacbbGcxdgWEBDbr.jpg', description: 'A massive natural wonder with breathtaking views.', region: 'North America' },
  { name: 'GTimes Square (New York City, USA)', image: 'https://upload.wikimedia.org/wikipedia/commons/b/bb/42nd_Street_in_New_York.jpg', description: 'Iconic for its bright lights and hustle.', region: 'North America' },
  { name: 'Mayan Ruins of Chichen Itza (Mexico)', image: 'https://www.globeguide.ca/wp-content/uploads/2016/09/Mexico-Chichen-Itza-ruins-2-1024x683.jpg', description: 'A famous archaeological site.', region: 'North America' },
  { name: 'Yellowstone National Park (USA)', image: 'https://assets.editorial.aetnd.com/uploads/2017/03/most-popular-geyser-in-the.jpg?width=1920&height=1078&crop=1920:1078,smart&quality=75&auto=webp', description: ' Known for geysers, wildlife, and stunning landscapes.', region: 'North America' },
  { name: 'Machu Picchu (Peru)', image: 'https://media.gettyimages.com/id/632209647/photo/machu-picchu-peru.jpg?s=612x612&w=0&k=20&c=f_piC1_VB-3SDtgkjFHVPcs4aYvC47r8ldTXQNv8tNI=', description: 'Ancient Incan ruins set in the Andes Mountains.', region: 'South America' },
  { name: 'Iguazu Falls (Argentina/Brazil)', image: 'https://cdn.thecollector.com/wp-content/uploads/2022/10/Christ_the_Redeemer.jpg', description: 'AThe famous statue overlooking Rio de Janeiro.', region: 'South America' },
  { name: 'Christ the Redeemer (Brazil)', image: 'https://media.gettyimages.com/id/930538824/photo/iguazu-falls-brazil-argentina-brazilian-side.jpg?s=612x612&w=0&k=20&c=l0rCWmS8I6iGEQWdF5xPrejTkmAbwOLowefXpcWgK0M=', description: 'One of the largest waterfall systems in the world.', region: 'South America' },
  { name: 'Galápagos Islands (Ecuador)', image: 'https://www.travelandleisure.com/thmb/WzL019sDotA4SIo4bacRrE4j_N0=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/galapagos-islands-ecuador-GALAPA1104-d013219debf14369ab5039a4eafb496e.jpg', description: ' A wildlife paradise with unique species.', region: 'South America' },
  { name: 'Atacama Desert (Chile)', image: 'https://cdn.britannica.com/70/186370-138-9165838E/Atacama-Desert-fog-fresh-water-Chile-Aloe.jpg?w=800&h=450&c=crop', description: ' One of the driest places on Earth with amazing landscapes.', region: 'South America' },
  { name: 'Serengeti National Park (Tanzania)', image: 'https://media.istockphoto.com/id/1191220251/photo/lions-on-top-of-the-rock-in-serengeti-tanzania.jpg?s=612x612&w=0&k=20&c=AoQbL0Avtdjh5LSb5XXBJvnHDrlaKqRJmivvverv3Pg=', description: 'Known for wildlife safaris and the Great Migration.', region: 'Africa' },
  { name: 'Table Mountain (South Africa)', image: 'https://cdn.britannica.com/41/75841-050-FAAE44F0/Table-Mountain-Cape-Town-Western-Bay-South.jpg?w=400&h=300&c=crop', description: 'A flat-topped mountain offering great views of Cape Town.', region: 'Africa' },
  { name: 'Mount Kilimanjaro (Tanzania)', image: 'https://t3.ftcdn.net/jpg/06/36/60/12/360_F_636601279_ao6jHfUCCRU382b9LkBs5SWnbDRJcqr4.jpg', description: 'The tallest mountain in Africa, popular for climbers.', region: 'Africa' },
  { name: 'Great Barrier Reef (Australia)', image: 'https://i.natgeofe.com/n/729f75ed-2a57-4186-beec-c53f7c8f8219/93075.jpg', description: 'The largest coral reef system in the world.', region: 'Australia' },
  { name: 'Sydney Opera House (Australia)', image: 'https://media.gettyimages.com/id/200114073-001/photo/australia-sydney-sydney-opera-house-and-skyline.jpg?s=612x612&w=0&k=20&c=9-i1_iW6dFIHSvy-LcxRhdRGy7xSNPirwOluSwIS4_g=', description: 'An architectural icon in Sydney.', region: 'Australia' },
  { name: 'Fiordland National Park (New Zealand) ', image: 'https://www.tripsavvy.com/thmb/AliL3fIIRVtpJUaYnTzyWYzQzek=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/kepler-track-hiking-trail--luxmore-hat--fiordland-national-park--southland--south-island--new-zealand-1282447799-034fed5ec4604df1b95b2309443d88f3.jpg', description: ' Known for its fjords, especially Milford Sound.', region: 'Australia' },
  { name: 'Bora Bora (French Polynesia)', image: 'https://lesdeuxpiedsdehors.com/wp-content/uploads/2019/03/ou-randonner-a-bora-bora.jpg', description: 'Famous for its overwater bungalows and stunning lagoons.', region: 'Australia' },
];

const HomeScreen = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [region, setRegion] = useState('All');
  const navigate = useNavigate();

  const regions = ['All', 'Europe', 'Asia', 'North America', 'Australia', 'Africa', 'Middle East', 'South America'];

  const filteredDestinations = destinations.filter((destination) => {
    const matchesSearchTerm = destination.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRegion = region === 'All' || destination.region === region;
    return matchesSearchTerm && matchesRegion;
  });

  const handleDestinationClick = (destinationName) => {
    navigate(`/booking/${destinationName}`);
  };

  return (
    <div className="home-screen">
      <h1>Popular Travel Destinations</h1>

      {/* Search Bar */}
      <input
        type="text"
        placeholder="Search by destination..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="search-bar"
      />

      {/* Region Filter */}
      <select
        value={region}
        onChange={(e) => setRegion(e.target.value)}
        className="region-filter"
      >
        {regions.map((regionOption, index) => (
          <option key={index} value={regionOption}>
            {regionOption}
          </option>
        ))}
      </select>

      {/* Destination Grid */}
      <div className="grid-container">
        {filteredDestinations.length > 0 ? (
          filteredDestinations.map((destination, index) => (
            <div
              key={index}
              className="grid-item"
              onClick={() => handleDestinationClick(destination.name)}
              style={{ cursor: 'pointer' }}  // Make it clear that it's clickable
            >
              <img
                src={destination.image}
                alt={destination.name}
                className="destination-image"
              />
              <h3>{destination.name}</h3>
              <p>{destination.description}</p>
            </div>
          ))
        ) : (
          <p>No destinations found.</p>
        )}
      </div>
    </div>
  );
};

export default HomeScreen;


/*
const destinations = [
  { name: 'Paris', image: 'https://media.istockphoto.com/id/1463510971/photo/paris-france.webp?a=1&b=1&s=612x612&w=0&k=20&c=4F64zAzQM5oSLMr9DrbCyOkLECslFIHXx9t5HDY2xNk=', description: 'The city of lights', region: 'Europe' },
  { name: 'New York', image: 'https://media.gettyimages.com/id/904453184/photo/composite-image-of-mt-fuji-and-tokyo-skyline.jpg?s=612x612&w=0&k=20&c=EAJrI5nVsDuIkiv7o3NY1LsaZHRCcOWUOvk2g9FfFD0=', description: 'The big apple', region: 'North America' },
  { name: 'Tokyo', image: 'https://media.gettyimages.com/id/1459138081/photo/tokyo-sky-tree-tower-in-asakusa-district-tokyo-japan.jpg?s=612x612&w=0&k=20&c=GtqIvoVXY3DgQ4YOxKNisWgQJGZvCQ_6OYFHRccngTQ=', description: 'Explore the land of the rising sun', region: 'Asia' },
  { name: 'Rome', image: 'https://media.istockphoto.com/id/1346359672/photo/rome-italy.jpg?s=612x612&w=0&k=20&c=VX2Blx_hNQaRWNcjMMggMqwaK_YCXJ109Rk0IlE5nPA=', description: 'The eternal city', region: 'Europe' },
  { name: 'Bali', image: 'https://media.gettyimages.com/id/113824076/photo/floating-temple-bali.jpg?s=612x612&w=0&k=20&c=I36xFLAzGUuUMybmM9RUstLPa1bPTJXELXurIAQ91zU=', description: 'A tropical paradise', region: 'Asia' },
  { name: 'Sydney', image: 'https://media.gettyimages.com/id/468994239/photo/sydney.jpg?s=612x612&w=0&k=20&c=16AnH70SaaHh02GzTSrItExrDNXm3ZU1XnrzL8Ro6PU=', description: 'Famous for the Opera House', region: 'Australia' },
  { name: 'Dubai', image: 'https://media.istockphoto.com/id/1572334424/photo/dubai.jpg?s=612x612&w=0&k=20&c=pfiT0UlQD8fyF4zowN4uCToAcnCs8V11Ke-HSte_ooc=', description: 'A city of innovation', region: 'Middle East' },
  { name: 'Cairo', image: 'https://media.istockphoto.com/id/177039612/photo/tutankhamuns-funerary-mask.jpg?s=612x612&w=0&k=20&c=T_s3dFgH16fGVb_uP5pqDo7SWL1Qf4U2IeN3jPWEM4c=', description: 'Home to the pyramids', region: 'Africa' },
  { name: 'Victoria Falls', image: 'https://t3.ftcdn.net/jpg/07/37/75/20/360_F_737752046_EQQifjCVIv0b61vaPxBveg0zdVZTGZpv.jpg', description: 'Most spectacular waterfalls.', region: 'Africa' },
  { name: 'Pyramids of Giza', image: 'https://cdn-imgix.headout.com/mircobrands-content/image/71e15c4888f28f40a0a4e05bc5cde87b-osama-elsayed-vqRMXgVtGXM-unsplash.jpg?auto=format&w=1051.2&h=540&q=90&fit=fit', description: 'Ancient wonders and iconic structures', region: 'Africa' },
  { name: 'Agra', image: 'https://t4.ftcdn.net/jpg/05/22/08/63/360_F_522086374_baK6AUM90Eg5It4iGa4EBXO7QomOgxeu.jpg', description: 'Taj Mahal INDIA', region: 'Asia' },
  { name: 'Mount Fuji', image: 'https://media.gettyimages.com/id/1163659775/photo/mount-fuji-japan.jpg?s=612x612&w=0&k=20&c=bqUEYZIlWCPZpY9EqvjLn-g3jHQHxPFHHGGz9xSREBs=', description: 'A beautiful, iconic volcano.', region: 'Asia' },
  { name: 'Eiffel Tower', image: 'https://i0.wp.com/www.theparisphotographer.com/wp-content/uploads/2021/07/Cute-photos-with-the-Eiffel-Tower.jpg?resize=668,1000&quality=100&ssl=1', description: 'A world-famous landmark in Paris.', region: 'Europe' },
  { name: 'Santorini', image: 'https://media.gettyimages.com/id/504544111/photo/santorini-greece.jpg?s=612x612&w=0&k=20&c=MwBH3AJWwaxnXJ3prY7oDjhV2BPWJPd3OEDhvwQQAvU=', description: 'Whitewashed buildings and stunning sunsets.', region: 'Europe' },
  { name: 'Swiss Alps', image: 'https://media.gettyimages.com/id/AB13082/photo/switzerland-swiss-alps-mountains-reflected-in-lake-water.jpg?s=612x612&w=0&k=20&c=8s_HgpsazV5FBnwdpfgh4gWB-006scZ7Is4ZGdejImI=', description: 'Majestic mountains for skiing and hiking.', region: 'Europe' },
  { name: 'Uluru', image: 'https://media.istockphoto.com/id/697901510/photo/uluru-at-sunset.jpg?s=612x612&w=0&k=20&c=QLo0oo2_vnKHjb2_tasm331UScJmSfC80AYufD0haFo=', description: 'A massive sandstone monolith in the Northern Territory', region: 'Australia' },
  { name: 'Great Wall of China (China)', image: 'https://media.istockphoto.com/id/500798097/photo/china-view-of-great-wall.jpg?s=612x612&w=0&k=20&c=bFk_2RzX47-_JqUXembpqJVzFujWSWmu8_kswDGdFK4=', description: 'One of the worlds greatest wonders', region: 'Asia' },
  { name: 'Angkor Wat (Cambodia)', image: 'https://i.natgeofe.com/n/ecc4af4e-7bd2-40cc-a854-62ca89d7f96b/93405.jpg', description: 'A stunning temple complex.', region: 'Asia' },
  { name: 'SColosseum (Italy) ', image: 'https://images.nationalgeographic.org/image/upload/t_edhub_resource_key_image/v1652340658/EducationHub/photos/colosseum.jpg', description: ' An ancient Roman amphitheater in Rome', region: 'Europe' },
  { name: 'Sagrada Familia (Spain) ', image: 'https://www.thevintagenews.com/wp-content/uploads/sites/65/2019/06/sagrada-familia-cathedral-in-barcelona-picture-id481444484.jpg', description: ' A unique basilica in Barcelona, designed by Gaudí.', region: 'Europe' },
  { name: 'Grand Canyon (USA)', image: 'https://t3.ftcdn.net/jpg/03/41/96/18/360_F_341961895_qTWc1ePPmvEAYHm5sacbbGcxdgWEBDbr.jpg', description: 'A massive natural wonder with breathtaking views.', region: 'North America' },
  { name: 'GTimes Square (New York City, USA)', image: 'https://upload.wikimedia.org/wikipedia/commons/b/bb/42nd_Street_in_New_York.jpg', description: 'Iconic for its bright lights and hustle.', region: 'North America' },
  { name: 'Mayan Ruins of Chichen Itza (Mexico)', image: 'https://www.globeguide.ca/wp-content/uploads/2016/09/Mexico-Chichen-Itza-ruins-2-1024x683.jpg', description: 'A famous archaeological site.', region: 'North America' },
  { name: 'Yellowstone National Park (USA)', image: 'https://assets.editorial.aetnd.com/uploads/2017/03/most-popular-geyser-in-the.jpg?width=1920&height=1078&crop=1920:1078,smart&quality=75&auto=webp', description: ' Known for geysers, wildlife, and stunning landscapes.', region: 'North America' },
  { name: 'Machu Picchu (Peru)', image: 'https://media.gettyimages.com/id/632209647/photo/machu-picchu-peru.jpg?s=612x612&w=0&k=20&c=f_piC1_VB-3SDtgkjFHVPcs4aYvC47r8ldTXQNv8tNI=', description: 'Ancient Incan ruins set in the Andes Mountains.', region: 'South America' },
  { name: 'Iguazu Falls (Argentina/Brazil)', image: 'https://cdn.thecollector.com/wp-content/uploads/2022/10/Christ_the_Redeemer.jpg', description: 'AThe famous statue overlooking Rio de Janeiro.', region: 'South America' },
  { name: 'Christ the Redeemer (Brazil)', image: 'https://media.gettyimages.com/id/930538824/photo/iguazu-falls-brazil-argentina-brazilian-side.jpg?s=612x612&w=0&k=20&c=l0rCWmS8I6iGEQWdF5xPrejTkmAbwOLowefXpcWgK0M=', description: 'One of the largest waterfall systems in the world.', region: 'South America' },
  { name: 'Galápagos Islands (Ecuador)', image: 'https://www.travelandleisure.com/thmb/WzL019sDotA4SIo4bacRrE4j_N0=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/galapagos-islands-ecuador-GALAPA1104-d013219debf14369ab5039a4eafb496e.jpg', description: ' A wildlife paradise with unique species.', region: 'South America' },
  { name: 'Atacama Desert (Chile)', image: 'https://cdn.britannica.com/70/186370-138-9165838E/Atacama-Desert-fog-fresh-water-Chile-Aloe.jpg?w=800&h=450&c=crop', description: ' One of the driest places on Earth with amazing landscapes.', region: 'South America' },
  { name: 'Serengeti National Park (Tanzania)', image: 'https://media.istockphoto.com/id/1191220251/photo/lions-on-top-of-the-rock-in-serengeti-tanzania.jpg?s=612x612&w=0&k=20&c=AoQbL0Avtdjh5LSb5XXBJvnHDrlaKqRJmivvverv3Pg=', description: 'Known for wildlife safaris and the Great Migration.', region: 'Africa' },
  { name: 'Table Mountain (South Africa)', image: 'https://cdn.britannica.com/41/75841-050-FAAE44F0/Table-Mountain-Cape-Town-Western-Bay-South.jpg?w=400&h=300&c=crop', description: 'A flat-topped mountain offering great views of Cape Town.', region: 'Africa' },
  { name: 'Mount Kilimanjaro (Tanzania)', image: 'https://t3.ftcdn.net/jpg/06/36/60/12/360_F_636601279_ao6jHfUCCRU382b9LkBs5SWnbDRJcqr4.jpg', description: 'The tallest mountain in Africa, popular for climbers.', region: 'Africa' },
  { name: 'Great Barrier Reef (Australia)', image: 'https://i.natgeofe.com/n/729f75ed-2a57-4186-beec-c53f7c8f8219/93075.jpg', description: 'The largest coral reef system in the world.', region: 'Australia' },
  { name: 'Sydney Opera House (Australia)', image: 'https://media.gettyimages.com/id/200114073-001/photo/australia-sydney-sydney-opera-house-and-skyline.jpg?s=612x612&w=0&k=20&c=9-i1_iW6dFIHSvy-LcxRhdRGy7xSNPirwOluSwIS4_g=', description: 'An architectural icon in Sydney.', region: 'Australia' },
  { name: 'Fiordland National Park (New Zealand) ', image: 'https://www.tripsavvy.com/thmb/AliL3fIIRVtpJUaYnTzyWYzQzek=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/kepler-track-hiking-trail--luxmore-hat--fiordland-national-park--southland--south-island--new-zealand-1282447799-034fed5ec4604df1b95b2309443d88f3.jpg', description: ' Known for its fjords, especially Milford Sound.', region: 'Australia' },
  { name: 'Bora Bora (French Polynesia)', image: 'https://lesdeuxpiedsdehors.com/wp-content/uploads/2019/03/ou-randonner-a-bora-bora.jpg', description: 'Famous for its overwater bungalows and stunning lagoons.', region: 'Australia' },

];

const HomeScreen = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [region, setRegion] = useState('All');

  const regions = ['All', 'Europe', 'Asia', 'North America', 'Australia', 'Africa', 'Middle East','South America'];

  const filteredDestinations = destinations.filter((destination) => {
    const matchesSearchTerm = destination.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRegion = region === 'All' || destination.region === region;
    return matchesSearchTerm && matchesRegion;
  });

  return (
    <div className="home-screen">
      <h1>Popular Travel Destinations</h1>

      {/* Search Bar }
      <input
        type="text"
        placeholder="Search by destination..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="search-bar"
      />

      { Region Filter }
      <select
        value={region}
        onChange={(e) => setRegion(e.target.value)}
        className="region-filter"
      >
        {regions.map((regionOption, index) => (
          <option key={index} value={regionOption}>
            {regionOption}
          </option>
        ))}
      </select>

{ Destination Grid } 
      <div className="grid-container">
        {filteredDestinations.length > 0 ? (
          filteredDestinations.map((destination, index) => (
            <div key={index} className="grid-item">
              <img
                src={destination.image}
                alt={destination.name}
                className="destination-image"
              />
              <h3>{destination.name}</h3>
              <p>{destination.description}</p>
            </div>
          ))
        ) : (
          <p>No destinations found.</p>
        )}
      </div>
    </div>
  );
};

export default HomeScreen;
*/