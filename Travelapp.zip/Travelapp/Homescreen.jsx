import React from 'react';
import './HomeScreen.css'; 

const destinations = [
  { name: 'Paris', image: 'https://media.istockphoto.com/id/1463510971/photo/paris-france.webp?a=1&b=1&s=612x612&w=0&k=20&c=4F64zAzQM5oSLMr9DrbCyOkLECslFIHXx9t5HDY2xNk=', description: 'The city of lights' },
  { name: 'New York', image: 'https://media.gettyimages.com/id/904453184/photo/composite-image-of-mt-fuji-and-tokyo-skyline.jpg?s=612x612&w=0&k=20&c=EAJrI5nVsDuIkiv7o3NY1LsaZHRCcOWUOvk2g9FfFD0=', description: 'The big apple' },
  { name: 'Tokyo', image: 'https://media.gettyimages.com/id/1459138081/photo/tokyo-sky-tree-tower-in-asakusa-district-tokyo-japan.jpg?s=612x612&w=0&k=20&c=GtqIvoVXY3DgQ4YOxKNisWgQJGZvCQ_6OYFHRccngTQ=', description: 'Explore the land of the rising sun' },
  { name: 'Rome', image: 'https://media.istockphoto.com/id/1346359672/photo/rome-italy.jpg?s=612x612&w=0&k=20&c=VX2Blx_hNQaRWNcjMMggMqwaK_YCXJ109Rk0IlE5nPA=', description: 'The eternal city' },
  { name: 'Bali', image: 'https://media.gettyimages.com/id/113824076/photo/floating-temple-bali.jpg?s=612x612&w=0&k=20&c=I36xFLAzGUuUMybmM9RUstLPa1bPTJXELXurIAQ91zU=', description: 'A tropical paradise' },
  { name: 'Sydney', image: 'https://media.gettyimages.com/id/468994239/photo/sydney.jpg?s=612x612&w=0&k=20&c=16AnH70SaaHh02GzTSrItExrDNXm3ZU1XnrzL8Ro6PU=', description: 'Famous for the Opera House' },
  { name: 'Dubai', image: 'https://media.istockphoto.com/id/1572334424/photo/dubai.jpg?s=612x612&w=0&k=20&c=pfiT0UlQD8fyF4zowN4uCToAcnCs8V11Ke-HSte_ooc=', description: 'A city of innovation' },
  { name: 'Cairo', image: 'https://media.istockphoto.com/id/177039612/photo/tutankhamuns-funerary-mask.jpg?s=612x612&w=0&k=20&c=T_s3dFgH16fGVb_uP5pqDo7SWL1Qf4U2IeN3jPWEM4c=', description: 'Home to the pyramids' },
];

const HomeScreen = () => {
  return (
    <div className="home-screen">
      <h1>Popular Travel Destinations</h1>
      <div className="grid-container">
        {destinations.map((destination, index) => (
          <div key={index} className="grid-item">
            <img src={destination.image} alt={destination.name} className="destination-image" />
            <h3>{destination.name}</h3>
            <p>{destination.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HomeScreen;
