import { useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import "./Signup.css";
import { auth } from "./firebase";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { db } from "./firebase"
import { doc, setDoc } from "firebase/firestore"; 

const Signup = () => {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [MobileNo, setMobileNo] = useState('');
  const navigate = useNavigate();

  const onSubmit = async () => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      await setDoc(doc(db, "user", user.uid), {
        username: username,
        email: email,
        MobileNo: MobileNo,
        uid: user.uid, // Store uid as well
      });
      console.log("User registered: ", user);
      navigate("/login");
    } catch (error) {
      console.error("Error signing up: ", error);
    }
  };

  const handleLoginRedirect = () => {
    navigate("/login");
  };

  return (
    <div className='container'>
      <form onSubmit={handleSubmit(onSubmit)}>
        <h1>Registration Form</h1>
        <div className='ui divider'></div>
        <div className='ui form'>
          <div className='field'>
            <label>Username</label>
            <input
              type='text'
              {...register("username", { required: "Username is required" })}
              placeholder='Username'
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
            <p>{errors.username?.message}</p>
          </div>

          <div className='field'>
            <label>Email</label>
            <input
              type='email'
              {...register("email", {
                required: "Email is required",
                pattern: { value: /^\S+@\S+$/i, message: "This is not a valid email" }
              })}
              placeholder='Email'
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <p>{errors.email?.message}</p>
          </div>

          <div className='field'>
            <label>Password</label>
            <input
              type='password'
              value={password}
              {...register("password", {
                required: "Password is required",
                minLength: { value: 4, message: "Password must be more than 4 characters" },
                maxLength: { value: 10, message: "Password cannot exceed more than 10 characters" }
              })}
              placeholder='Password'
              onChange={(e) => setPassword(e.target.value)}
            />
            <p>{errors.password?.message}</p>
          </div>

          <div className='field'>
            <label>Mobile Number</label>
            <input
              type='text'
              {...register("MobileNo", {
                required: "Mobile No is required",
                minLength: { value: 10, message: "Mobile No must be more than 10 characters" },
                maxLength: { value: 14, message: "Mobile No cannot exceed more than 14 characters" }
              })}
              value={MobileNo}
              placeholder='Mobile No'
              onChange={(e) => setMobileNo(e.target.value)}
            />
            <p>{errors.MobileNo?.message}</p>
          </div>

          <button type='submit' className='fluid ui button blue'>Signup</button>
        </div>
      </form>

      <div>
        <label>If you already have an account, then click Login</label>
        <button id="Loginbutton" className='fluid ui button blue' onClick={handleLoginRedirect}>
          Login
        </button>
      </div>
    </div>
  );
};

export default Signup;