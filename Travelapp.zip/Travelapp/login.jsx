import { useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";  
import { auth } from "./firebase"; // Ensure this path is correct
import { signInWithEmailAndPassword } from "firebase/auth";
import "./login.css"; 

const Login = () => {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const [loginError, setLoginError] = useState('');
  const navigate = useNavigate();  

  const onSubmit = async (data) => {
    const { email, password } = data;

    try {
      await signInWithEmailAndPassword(auth, email, password);
      navigate("../Homescreen");  
    } catch (error) {
     
      switch (error.code) {
        case 'auth/user-not-found':
          setLoginError('No user found with this email.');
          break;
        case 'auth/wrong-password':
          setLoginError('Incorrect password. Please try again.');
          break;
        default:
          setLoginError('An error occurred. Please try again.');
          break;
      }
    }
  };

  return (
    <div className="container">
      <form onSubmit={handleSubmit(onSubmit)} className="form">
        <h1>Login to Account</h1>
        <div className="ui divider"></div>
        <div className="ui form">
          <div className="field">
            <label>Username</label>
            <input
              type="text"
              {...register("username", { required: "Username is required" })}
              placeholder="Username"
            />
            <p>{errors.username?.message}</p>
          </div>

          <div className="field">
            <label>Email</label>
            <input
              type="email"
              {...register("email", {
                required: "Email is required",
                pattern: { value: /^\S+@\S+$/i, message: "This is not a valid email" }
              })}
              placeholder="Email"
            />
            <p>{errors.email?.message}</p>
          </div>

          <div className="field">
            <label>Password</label>
            <input
              type="password"
              {...register("password", {
                required: "Password is required",
                minLength: { value: 4, message: "Password must be more than 4 characters" },
                maxLength: { value: 16, message: "Password cannot exceed more than 16 characters" }
              })}
              placeholder="Password"
            />
            <p>{errors.password?.message}</p>
          </div>

          {loginError && <p className="error-message">{loginError}</p>} {/* Display error message */}

          <button type="submit" className="fluid ui button blue">Login</button>
        </div>
      </form>
    </div>
  );
};

export default Login;
